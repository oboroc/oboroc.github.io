MMIL23.BIN is BIOS v2.3 for original Matrox Millennium PCI SVGA video card.

You'll need progbios.exe and dos4gw.exe files from Matrox BIOS update:

ftp://ftp.matrox.com/pub/mga/bios/setup351.zip

To flash, run this command:

progbios.exe -i MMIL23.BIN

Please make sure SW1 is set to ON (BIOS unprotected) or flashing will fail.

More details here: http://www.oboroc.com/posts/2016/07/01/my-matrox-video-cards/

